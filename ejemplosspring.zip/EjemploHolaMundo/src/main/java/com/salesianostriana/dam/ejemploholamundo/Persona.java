package com.salesianostriana.dam.ejemploholamundo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class Persona {
	
	private String nombre;
	private String apellidos;
	
	
	
	
	

}
