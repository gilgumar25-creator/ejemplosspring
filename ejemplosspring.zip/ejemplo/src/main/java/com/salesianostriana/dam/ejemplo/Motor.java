package com.salesianostriana.dam.ejemplo;

public interface Motor {
	
	void arrancar();
	void acelerar();
	void frenar();
	void apagar();
	

}
